DataBindingDemo (Session01)
==========================
Demo theo toàn bộ hướng dẫn trên trang chủ của Google.
<br/>http://developer.android.com/tools/data-binding/guide.html
<br/> ![](https://raw.githubusercontent.com/9xkun/102-androiM-whathot/master/Tutor01Day02_DataBindingDemo/apk/DataBinding_Demo02.gif)

Thư mục apk chứa file chạy, mọi người kéo vào thiết bị và trải nghiệm app hoạt động thế nào nhé.
<br/> Apk file: https://github.com/9xkun/102-androiM-whathot/raw/master/Tutor01Day02_DataBindingDemo/apk/databindingdemo-debug.apk

Còn nếu siêu lười nữa thì mọi người chơi thử app trên web:
<br/> https://appetize.io/app/971a67aahz0e3qa5xkzyrb78ur?device=nexus5&scale=75&orientation=portrait&osVersion=5.1

## Setup
Vì mình cho tất cả các source vào chung 1 dự án nên nếu các bạn git clone sẽ lấy cả repo về (có thể sẽ rất to. Một giải pháp nữa là sử dụng git sparse http://jasonkarns.com/blog/subdirectory-checkouts-with-git-sparse-checkout/)
<br/> Do đó mọi người có thể tải file src được nén riêng ở link sau
<br/> https://github.com/9xkun/102-androiM-whathot/raw/master/Tutor01Day02_DataBindingDemo/apk/Tutor01Day02_DataBindingDemo.zip
<br/> Sau đó giải nén bằng 7zip,winrar,winzip, ...  và import vào Android Studio.

## Chú ý
Mọi người có thể tới link này để tham khảo toàn bộ thư viện DataBinding
<br/> https://developer.android.com/tools/data-binding/guide.html

hoặc nếu cần tham khảo prj thật có sử dụng databinding, hãy đăng ký học link này:
<br/> http://techmaster.vn/khoa-hoc/25482/101-android-khai-vi

hoặc lên trang của 9xkun.com, có 1 số link sau cho các bạn tham khảo:
<br/> Khóa học: http://iziroi.9xkun.com/course/103-androidM-whathot
<br/> Tuts: http://iziroi.9xkun.com/tuts/article/
